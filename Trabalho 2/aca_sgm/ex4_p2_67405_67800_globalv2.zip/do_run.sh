make
./sgm
